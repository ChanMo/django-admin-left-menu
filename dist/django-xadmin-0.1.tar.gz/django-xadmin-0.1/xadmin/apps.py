from django.apps import AppConfig


class XadminConfig(AppConfig):
    name = 'xadmin'
