default_app_config='xadmin.apps.XadminConfig'
